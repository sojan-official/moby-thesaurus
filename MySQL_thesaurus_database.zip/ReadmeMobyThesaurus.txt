The Project Gutenberg Etext of Moby Thesaurus II by Grady Ward

Copyright laws are changing all over the world, be sure to check
the laws for your country before redistributing these files!!!

Please take a look at the important information in this header.
We encourage you to keep this file on your own disk, keeping an
electronic path open for the next readers.  Do not remove this.

This should be the first thing seen when anyone opens the book.
Do not change or edit it without written permission.  The words
are carefully chosen to provide users with the information they
need about what they can legally do with the texts.

**Welcome To The World of Free Plain Vanilla Electronic Texts**

**Etexts Readable By Both Humans and By Computers, Since 1971**

*These Etexts Prepared By Hundreds of Volunteers and Donations*

Information on contacting Project Gutenberg to get Etexts, and
further information is included below.  We need your donations.

Presently, contributions are only being solicited from people in:
Texas, Nevada, Idaho, Montana, Wyoming, Colorado, South Dakota,
Iowa, Indiana, and Vermont. As the requirements for other states
are met, additions to this list will be made and fund raising will
begin in the additional states. These donations should be made to:

Project Gutenberg Literary Archive Foundation
PMB 113
1739 University Ave.
Oxford, MS 38655

Title:  Moby Thesaurus II

Author:  Grady Ward, grady@gradyward.com

Release Date:  May, 2002  [Etext #3202]

Edition:  1.0

The Project Gutenberg Etext of Moby Thesaurus II by Grady Ward
******This file should be named mthes10.zip******

Corrected EDITIONS of our etexts get a new NUMBER, mthes11.zip
VERSIONS based on separate sources get new LETTER, mthes10a.zip

This etext was prepared by Mike Pullen, 
globaltraveler5565@yahoo.com.

Project Gutenberg Etexts are usually created from multiple editions,
all of which are in the Public Domain in the United States, unless a
copyright notice is included.  Therefore, we usually do NOT keep any
of these books in compliance with any particular paper edition.

We are now trying to release all our books one year in advance
of the official release dates, leaving time for better editing.
Please be encouraged to send us error messages even years after
the official publication date.

Please note:  neither this list nor its contents are final till
midnight of the last day of the month of any such announcement.
The official release date of all Project Gutenberg Etexts is at
Midnight, Central Time, of the last day of the stated month.  A
preliminary version may often be posted for suggestion, comment
and editing by those who wish to do so.

Most people start at our sites at:
http://gutenberg.net/pg
http://promo.net/pg

Those of you who want to download our Etexts before announcment
can surf to them as follows, and just download by date; this is
also a good way to get them instantly upon announcement, as the
indexes our cataloguers produce obviously take a while after an
announcement goes out in the Project Gutenberg Newsletter.

http://metalab.unc.edu/pub/docs/books/gutenberg/etext01
or
ftp://metalab.unc.edu/pub/docs/books/gutenberg/etext01

Or /etext00, 99, 98, 97, 96, 95, 94, 93, 92, 92, 91 or 90

Just search by the first five letters of the filename you want,
as it appears in our Newsletters.

Information about Project Gutenberg (one page)

We produce about two million dollars for each hour we work.  The
time it takes us, a rather conservative estimate, is fifty hours
to get any etext selected, entered, proofread, edited, copyright
searched and analyzed, the copyright letters written, etc.  This
projected audience is one hundred million readers.  If our value
per text is nominally estimated at one dollar then we produce $2
million dollars per hour this year as we release fifty new Etext
files per month, or 500 more Etexts in 2000 for a total of 3000+
If they reach just 1-2% of the world's population then the total
should reach over 300 billion Etexts given away by year's end.

The Goal of Project Gutenberg is to Give Away One Trillion Etext
Files by December 31, 2001.  [10,000 x 100,000,000 = 1 Trillion]
This is ten thousand titles each to one hundred million readers,
which is only about 4% of the present number of computer users.

At our revised rates of production, we will reach only one-third
of that goal by the end of 2001, or about 3,333 Etexts unless we
manage to get some real funding.

Something is needed to create a future for Project Gutenberg for
the next 100 years.

We need your donations more than ever!

Presently, contributions are only being solicited from people in:
Texas, Nevada, Idaho, Montana, Wyoming, Colorado, South Dakota,
Iowa, Indiana, and Vermont. As the requirements for other states
are met, additions to this list will be made and fund raising will
begin in the additional states.

All donations should be made to the Project Gutenberg Literary
Archive Foundation and will be tax deductible to the extent
permitted by law.

Mail to:

Project Gutenberg Literary Archive Foundation
PMB 113
1739 University Avenue
Oxford, MS 38655  [USA]

We are working with the Project Gutenberg Literary Archive
Foundation to build more stable support and ensure the
future of Project Gutenberg.

We need your donations more than ever!

You can get up to date donation information at:

http://www.gutenberg.net/donation.html

***

You can always email directly to:

Michael S. Hart <hart@pobox.com>

hart@pobox.com forwards to hart@prairienet.org and archive.org
if your mail bounces from archive.org, I will still see it, if
it bounces from prairienet.org, better resend later on. . . .

We would prefer to send you this information by email.

Example command-line FTP session:

ftp metalab.unc.edu
login: anonymous
password: your@login
cd pub/docs/books/gutenberg
cd etext90 through etext99 or etext00 through etext01, etc.
dir [to see files]
get or mget [to get files. . .set bin for zip files]
GET GUTINDEX.??  [to get a year's listing of books, e.g.,
GUTINDEX.99]
GET GUTINDEX.ALL [to get a listing of ALL books]

**The Legal Small Print**

(Three Pages)

***START**THE SMALL PRINT!**FOR PUBLIC DOMAIN ETEXTS**START***
Why is this "Small Print!" statement here?  You know: lawyers.
They tell us you might sue us if there is something wrong with
your copy of this etext, even if you got it for free from
someone other than us, and even if what's wrong is not our
fault.  So, among other things, this "Small Print!" statement
disclaims most of our liability to you.  It also tells you how
you can distribute copies of this etext if you want to.

*BEFORE!* YOU USE OR READ THIS ETEXT
By using or reading any part of this PROJECT GUTENBERG-tm
etext, you indicate that you understand, agree to and accept
this "Small Print!" statement.  If you do not, you can receive
a refund of the money (if any) you paid for this etext by
sending a request within 30 days of receiving it to the person
you got it from.  If you received this etext on a physical
medium (such as a disk), you must return it with your request.

ABOUT PROJECT GUTENBERG-TM ETEXTS
This PROJECT GUTENBERG-tm etext, like most PROJECT GUTENBERG-tm
etexts,
is a "public domain" work distributed by Professor Michael S. Hart
through the Project Gutenberg Association (the "Project").
Among other things, this means that no one owns a United States
copyright
on or for this work, so the Project (and you!) can copy and
distribute it in the United States without permission and
without paying copyright royalties.  Special rules, set forth
below, apply if you wish to copy and distribute this etext
under the Project's "PROJECT GUTENBERG" trademark.

To create these etexts, the Project expends considerable
efforts to identify, transcribe and proofread public domain
works.  Despite these efforts, the Project's etexts and any
medium they may be on may contain "Defects".  Among other
things, Defects may take the form of incomplete, inaccurate or
corrupt data, transcription errors, a copyright or other
intellectual property infringement, a defective or damaged
disk or other etext medium, a computer virus, or computer
codes that damage or cannot be read by your equipment.

LIMITED WARRANTY; DISCLAIMER OF DAMAGES
But for the "Right of Replacement or Refund" described below,
[1] the Project (and any other party you may receive this
etext from as a PROJECT GUTENBERG-tm etext) disclaims all
liability to you for damages, costs and expenses, including
legal fees, and [2] YOU HAVE NO REMEDIES FOR NEGLIGENCE OR
UNDER STRICT LIABILITY, OR FOR BREACH OF WARRANTY OR CONTRACT,
INCLUDING BUT NOT LIMITED TO INDIRECT, CONSEQUENTIAL, PUNITIVE
OR INCIDENTAL DAMAGES, EVEN IF YOU GIVE NOTICE OF THE
POSSIBILITY OF SUCH DAMAGES.

If you discover a Defect in this etext within 90 days of
receiving it, you can receive a refund of the money (if any)
you paid for it by sending an explanatory note within that
time to the person you received it from.  If you received it
on a physical medium, you must return it with your note, and
such person may choose to alternatively give you a replacement
copy.  If you received it electronically, such person may
choose to alternatively give you a second opportunity to
receive it electronically.

THIS ETEXT IS OTHERWISE PROVIDED TO YOU "AS-IS".  NO OTHER
WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, ARE MADE TO YOU AS
TO THE ETEXT OR ANY MEDIUM IT MAY BE ON, INCLUDING BUT NOT
LIMITED TO WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE.

Some states do not allow disclaimers of implied warranties or
the exclusion or limitation of consequential damages, so the
above disclaimers and exclusions may not apply to you, and you
may have other legal rights.

INDEMNITY
You will indemnify and hold the Project, its directors,
officers, members and agents harmless from all liability, cost
and expense, including legal fees, that arise directly or
indirectly from any of the following that you do or cause:
[1] distribution of this etext, [2] alteration, modification,
or addition to the etext, or [3] any Defect.

DISTRIBUTION UNDER "PROJECT GUTENBERG-tm"
You may distribute copies of this etext electronically, or by
disk, book or any other medium if you either delete this
"Small Print!" and all other references to Project Gutenberg,
or:

[1]  Only give exact copies of it.  Among other things, this
     requires that you do not remove, alter or modify the
     etext or this "small print!" statement.  You may however,
     if you wish, distribute this etext in machine readable
     binary, compressed, mark-up, or proprietary form,
     including any form resulting from conversion by word pro-
     cessing or hypertext software, but only so long as
     *EITHER*:

     [*]  The etext, when displayed, is clearly readable, and
          does *not* contain characters other than those
          intended by the author of the work, although tilde
          (~), asterisk (*) and underline (_) characters may
          be used to convey punctuation intended by the
          author, and additional characters may be used to
          indicate hypertext links; OR

     [*]  The etext may be readily converted by the reader at
          no expense into plain ASCII, EBCDIC or equivalent
          form by the program that displays the etext (as is
          the case, for instance, with most word processors);
          OR

     [*]  You provide, or agree to also provide on request at
          no additional cost, fee or expense, a copy of the
          etext in its original plain ASCII form (or in EBCDIC
          or other equivalent proprietary form).

[2]  Honor the etext refund and replacement provisions of this
     "Small Print!" statement.

[3]  Pay a trademark license fee to the Project of 20% of the
     gross profits you derive calculated using the method you
     already use to calculate your applicable taxes.  If you
     don't derive profits, no royalty is due.  Royalties are
     payable to "Project Gutenberg Literary Archive Foundation"
     the 60 days following each date you prepare (or were
     legally required to prepare) your annual (or equivalent
     periodic) tax return.  Please contact us beforehand to
     let us know your plans and to work out the details.

WHAT IF YOU *WANT* TO SEND MONEY EVEN IF YOU DON'T HAVE TO?
The Project gratefully accepts contributions of money, time,
public domain etexts, and royalty free copyright licenses.
If you are interested in contributing scanning equipment or
software or other items, please contact Michael Hart at:
hart@pobox.com

*END THE SMALL PRINT! FOR PUBLIC DOMAIN ETEXTS*Ver.04.07.00*END*




Moby (tm) Thesaurus II Documentation Notes

This documentation, the software and/or database are:

Public Domain material by grant from the author, January, 2001.


Moby (tm) Thesaurus for the MSDOS operating system is compressed and
distributed as a single zip file.  After extraction, the vocabulary
files included with this product are in ordinary ASCII format with
CRLF (ASCII 13/10) delimiters.




MOBY Thesaurus II CONTENTS

This file (aaREADME.txt)
Unabridged Moby Main Thesaurus file (mthesaur.txt)

Roget 1911 (roget13a.txt)

NOTE: Accents have been stripped from words, e.g., 'etude' does not
mark the accent on the initial 'e'.

Moby Thesaurus is the largest and most comprehensive thesaurus data
source in English available for commercial use.  This second edition
has been thoroughly revised adding more than 5,000 root words (to
total more than 30,000) with an additional _million_ synonyms and
related terms (to total more than 2.5 _million_ synonyms and related
terms).  Although this thesaurus is provided in a very simple ASCII
format suitable to viewing, editing, and automatic parsing, most
users will consider reformatting schemes to represent the data in a
more economical form, such as table of related terms whose index can
be shared by many roots.  This is roughly the technique used by the
thesaurus in print form that has the large index coupled with the
synonyms under abstract (and arbitrary) headings in the front matter.
Tables of related terms can be stored in, for example, LZ compressed
form until actually required by the application.  Combining such
schemes could easily reduce the storage requirement of this data by
an order of magnitude or more.  The supplementary file, roget13a.txt,
provides a small thesaurus already organized in this form that you
may wish to use as a guide when developing your own categories of
synonyms.  Also, of course, uncommon words can be stripped out
according to the developer's criterion, keeping only the core and
most oftenly used information.  Once unarchived, the database format
is flat-file ASCII: each record (delimited from other records with a
terminal carriage return/linefeed [ASCII 13/10] character) is of the
form:

(In this example, the root word is 'frill', which is always the first
word of the list.  The synonyms and related words are listed in ASCII
alphabetical order after the root.  Each entry, including the root,
is followed by a comma.  The last entry in a record is followed by a
carriage return/linefeed [ASCII 13/10].)


frill, addition, adornment, amenity, beading, beauties, bedizenment,
binding, bonus, bordering, bordure, bravery, chiffon, clinquant,
colors, colors of rhetoric, crease, creasing, crimp, crisp,
decoration, dog-ear, double, double over, doubling, duplication,
duplication of effort, duplicature, edging, elegant variation,
embellishment, embroidery, enfold, expletive, extra, extra added
attraction, extra dash, extravagance, fat, featherbedding, festoons,
figure, figure of speech, filigree, filling, fillip, fimbria,
fimbriation, fine writing, finery, flection, flexure, floridity,
floridness, flounce, flourish, floweriness, flowers of speech, flute,
fold, fold over, folderol, foofaraw, frilliness, frilling, frills,
frills and furbelows, fringe, frippery, froufrou, furbelow, fuss,
gaiety, galloon, gather, gaudery, gewgaw, gilding, gilt, gingerbread,
hem,infold, interfold, jazz, lagniappe, lap over, lapel, lappet, list,
lushness, luxuriance, luxury, motif, needlessness, ornament,
ornamentation, ostentation, overadornment, overlap, padding, paste,
payroll padding, plait, plat, pleat, pleonasm, plica, plicate,
plication, plicature, ply, premium, prolixity, purple patches, quill,
redundance, redundancy, ruche, ruching, ruff, ruffle, selvage,
showiness, skirting, something extra, stuffing, superaddition,
superfluity, superfluousness, tautology, tinsel, trappings, trickery,
trimming, trumpery, tuck, turn over, twill, twist, unnecessariness,
valance, verbosity, welt, wrinkle
[carriage return]


Part-of-Speech information is not stored with this thesaurus.  A
separate file (mposp10.zip) available from Project Gutenberg by the
same author supplies a separate lexical database providing the
part(s)-of-speech for a large collection (>200,000) of English words
and phrases that can be used in conjunction with this list to supply
POS information if needed by the particular application.


Quick Start
1) Insure you have at least 26Mb of free disk space to hold the contents
   of this zip file.
2) Create a directory to hold these files listed above.
3) Extract the contents of this zip file into the destination directory
   using any compatible zip file extraction utility.
4) Delete the original zip file from your disk to save space.  (optional)


End of this Project Gutenberg etext of Moby Thesaurus II by Grady Ward.

