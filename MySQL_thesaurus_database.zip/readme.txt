Run the .sql file on your MySQL server to generate a relational moby_thesaurus MySQL database. 

Queries on this database can be executed much faster than the text based version.